﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int[] posicionPalabra;
        public int[] renglonespendientes = new int[0];
        public int[] renglonesRevisados = new int[0];

        public string[,] matriz = {
                        {"0", "0", "0", "0", "es", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "puede", "tiene", "pone", "es", "0", "0", "tiene", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "es", "puede", "es", "0", "puede", "0", "0", "0", "0", "puede", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "come", "puede", "tiene" , "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "es", "0", "0", "0", "0", "tiene", "es", "es"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
                        {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"} };

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            switch (comboBox1.SelectedIndex)
            {
                    //¿Que es?
                case 0:
                    if (buscarPalabra("es", 0) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("es", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }
                    analizarFaltantes("es");
                    break;
                    //¿Que tiene?
                case 2:
                    if (buscarPalabra("tiene", 1) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("tiene", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }
                   
                    break;
                    //¿Que puede?
                case 1:
                    if (buscarPalabra("puede", 4) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("puede", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }
                   
                    break;
                    //¿Que come?
                case 3:
                    if (buscarPalabra("come", 8) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("come", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }
                   
                    break;
                    //¿Que pone?
                case 4:
                    if (buscarPalabra("pone", 1) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("pone", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }

                   
                    break;
                case 5:
                    if (buscarPalabra("es", 12) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("pone", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }


                    break;
                case 6:
                    if (buscarPalabra("tiene", 12) == true)
                    {
                        while (true)
                        {
                            if (buscarPalabra("pone", posicionPalabra[0]) == true) continue;
                            else break;
                        }
                    }


                    break;
                default:
                    break;
            }

        }


        private void analizar()
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                
            }
        }

        private bool buscarPalabra(string palabra, int renglon)
        {
           posicionPalabra = new int[2];

           bool seguir = false;

            /* Buscar la palabra en la columna de la matriz*/
            for (int i = 0; i < matriz.GetLength(1); i++)
            {
                if (palabra == matriz[renglon, i].ToString())
                {
                    agregarSignificado(i);

                    posicionPalabra[0] = i;
                    posicionPalabra[1] = 0;

                    seguir = true;
                }
                else if (i == matriz.GetLength(1) - 1)
                {
                    Array.Resize(ref renglonesRevisados, renglonesRevisados.Length + 1);
                    renglonesRevisados[renglonesRevisados.Length-1] = renglon;
                }
            }

            return seguir;
        }
        private void agregarSignificado(int renglon)
        {
            if (renglon == 0)
            {
                listBox1.Items.Add("piolin");
            }
            else if (renglon== 1)
            {
                listBox1.Items.Add("pajaro");
            }
            else if (renglon == 2)
            {
                listBox1.Items.Add("cantar");
            }
            else if (renglon == 3)
            {
                listBox1.Items.Add("amarillo");
            }
            else if (renglon == 4)
            {
                listBox1.Items.Add("canario");
            }
            else if (renglon == 5)
            {
                listBox1.Items.Add("volar");
            }
            else if (renglon == 6)
            {
                listBox1.Items.Add("alas");
            }
            else if (renglon == 7)
            {
                listBox1.Items.Add("huevos");
            }
            else if (renglon == 8)
            {
                listBox1.Items.Add("animal");
            }
            else if (renglon == 9)
            {
                listBox1.Items.Add("alimentos");
            }
            else if (renglon == 10)
            {
                listBox1.Items.Add("respirar");
            }
            else if (renglon == 11)
            {
                listBox1.Items.Add("piel");
            }
            else if (renglon == 12)
            {
                listBox1.Items.Add("persona");
            }
            else if (renglon == 13)
            {
                listBox1.Items.Add("piernas y brazos");
            }
            else if (renglon == 14)
            {
                listBox1.Items.Add("carnivoro");
            }
            else if (renglon == 15)
            {
                listBox1.Items.Add("inteligente");
            }

            Array.Resize(ref renglonespendientes, renglonespendientes.Length + 1);
            renglonespendientes[renglonespendientes.Length - 1] = renglon;
        }
        private void analizarFaltantes(string palabra)
        {
            int[] renglonesFaltantes = new int[0];
            bool agregar = true;

            for (int j = 0; j < renglonespendientes.Length; j++)
            {
                agregar = true;
                for (int i = 0; i < renglonesRevisados.Length; i++)
                {
                    if (renglonesRevisados[i] == renglonespendientes[j])
                    {
                        agregar = false;
                    }

                }
                if (agregar == true)
                {
                    //Array.Resize(ref renglonesFaltantes, renglonesFaltantes.Length + 1);
                    //renglonesFaltantes[renglonesFaltantes.Length -1] = renglonespendientes[j];
                    buscarPalabra(palabra, j);
                }
            }
           
        }
    }
}
